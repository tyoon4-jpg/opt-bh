"""
optimized_beam_aisc.py
=======================
CIP (cast-in-place) drilled-hole steel beam optimizer — AISC 360-16 method.

PURPOSE
-------
Given a drilling hole diameter and a construction allowance (annular working
clearance), this script performs a grid search over a library of standard
AISC W-shapes to find the lightest section that:

  1. GEOMETRIC FIT  - fits diagonally within the drilled hole after the
                       construction allowance is subtracted, and
  2. STRENGTH        - satisfies AISC 360-16 flexure and shear checks (and,
                       optionally, combined axial-flexure interaction).

GEOMETRIC MODEL
----------------
A wide-flange section can rotate about its longitudinal axis during
insertion/plumbing. The governing clearance dimension is therefore the
CORNER-TO-CORNER DIAGONAL of the section, not its depth or flange width:

    diagonal = sqrt(d^2 + bf^2)

Net available diagonal within the hole:

    D_net = D_hole - 2 * C_allowance      (C_allowance applied per side)

A section is geometrically admissible only if:

    diagonal <= D_net

NOTE ON CONSTRUCTION ALLOWANCE VALUES (50 / 75 / 100 mm)
----------------------------------------------------------
These are NOT single-source AISC/OSHA values — no national code specifies a
beam-in-hole clearance directly. They are common contractor/spec-driven
tiers seen in soldier-pile and CIP pile practice, sized to cover:
  - drilling/plumbness tolerance (typically +/-1 in / 25 mm per common DOT
    special provisions),
  - minimum grout/concrete cover for corrosion protection & bond, and
  - clearance for tremie pipe or grout tube alongside the beam.
Treat the three tiers as defaults to be CONFIRMED against project-specific
specifications and hole diameter (larger holes / deeper plumbness tolerance
=> use the larger allowance). This is called out explicitly in the PRD.

STRENGTH MODEL (Phase 1 - screening grade, see PRD Section 5 for scope)
--------------------------------------------------------------------------
Flexure (Chapter F2, doubly symmetric compact I-shapes bent about strong axis):
    Mp  = Fy * Zx
    Lp  = 1.76 * ry * sqrt(E / Fy)
    Lr  ~ pi * ry * sqrt(E / (0.7 Fy))          [simplified screening form -
                                                   ignores warping/torsion
                                                   terms Cw, J; conservative
                                                   for preliminary sizing]
    Lb <= Lp        : Mn = Mp
    Lp < Lb <= Lr    : Mn = Cb*(Mp - (Mp-0.7*Fy*Sx)*(Lb-Lp)/(Lr-Lp)) <= Mp
    Lb > Lr          : Mn = Cb*Mp*(Lr/Lb)**2 <= Mp   [elastic approx.]
    phi_b = 0.90

    KEY PROJECT-SPECIFIC SIMPLIFICATION: once the annulus is filled with
    grout/concrete and cured, the beam is CONTINUOUSLY laterally braced by
    the surrounding fill, so Lb -> 0 and Mn = Mp governs the in-service
    condition. Lb > 0 should only be used to check the temporary
    (pre-grout / handling) condition. Set lb_construction_mm accordingly.

Shear (Chapter G2.1, unstiffened compact webs, Cv1 = 1.0 assumed):
    Vn = 0.6 * Fy * Aw * Cv1     Aw = d * tw
    phi_v = 0.90

Combined axial + flexure (Chapter H1-1a/b), optional if Pu supplied.

For final, stamped design, replace the simplified Lr/LTB terms with the
full AISC Manual Table 3-2/3-6 values (which include Cw, J, rts, ho) for
the specific section and unbraced length.

USAGE
-----
    python optimized_beam_aisc.py

Edit the INPUTS block below or import `optimize()` into another script /
the React app's backend.
"""

import math

# ----------------------------------------------------------------------
# 1. SECTION LIBRARY (US units: in, in^2, in^3, in^4, plf)
#    Indicative common values for a soldier-pile / CIP-pile size range.
#    VERIFY against the current AISC Steel Construction Manual before
#    use in final design — this table is for screening/optimization only.
# ----------------------------------------------------------------------
AISC_W_SHAPES = [
    # name,        d,     bf,    tw,    tf,    A,    Ix,    Sx,    Zx,   ry,   wt(plf)
    dict(name="W8x31",  d=8.00,  bf=7.995, tw=0.285, tf=0.435, A=9.13,  Ix=110,  Sx=27.5, Zx=30.4, ry=2.02, wt=31),
    dict(name="W8x40",  d=8.25,  bf=8.070, tw=0.360, tf=0.560, A=11.7,  Ix=146,  Sx=35.5, Zx=39.8, ry=2.04, wt=40),
    dict(name="W8x48",  d=8.50,  bf=8.110, tw=0.400, tf=0.685, A=14.1,  Ix=184,  Sx=43.2, Zx=49.0, ry=2.08, wt=48),
    dict(name="W10x33", d=9.73,  bf=7.960, tw=0.290, tf=0.435, A=9.71,  Ix=171,  Sx=35.0, Zx=38.8, ry=1.94, wt=33),
    dict(name="W10x45", d=10.10, bf=8.020, tw=0.350, tf=0.620, A=13.3,  Ix=248,  Sx=49.1, Zx=54.9, ry=2.01, wt=45),
    dict(name="W10x60", d=10.20, bf=10.080,tw=0.420, tf=0.680, A=17.6,  Ix=341,  Sx=66.7, Zx=74.6, ry=2.57, wt=60),
    dict(name="W12x40", d=11.90, bf=8.005, tw=0.295, tf=0.515, A=11.7,  Ix=307,  Sx=51.5, Zx=57.0, ry=1.94, wt=40),
    dict(name="W12x53", d=12.10, bf=9.995, tw=0.345, tf=0.575, A=15.6,  Ix=425,  Sx=70.6, Zx=77.9, ry=2.48, wt=53),
    dict(name="W12x65", d=12.10, bf=12.000,tw=0.390, tf=0.605, A=19.1,  Ix=533,  Sx=87.9, Zx=96.8, ry=3.02, wt=65),
    dict(name="W14x53", d=13.90, bf=8.060, tw=0.370, tf=0.660, A=15.6,  Ix=541,  Sx=77.8, Zx=87.1, ry=1.92, wt=53),
    dict(name="W14x68", d=14.00, bf=10.040,tw=0.415, tf=0.720, A=20.0,  Ix=722,  Sx=103,  Zx=115,  ry=2.46, wt=68),
    dict(name="W14x90", d=14.00, bf=14.520,tw=0.440, tf=0.710, A=26.5,  Ix=999,  Sx=143,  Zx=157,  ry=3.70, wt=90),
    dict(name="W16x89", d=16.75, bf=10.365,tw=0.525, tf=0.875, A=26.2,  Ix=1310, Sx=155,  Zx=175,  ry=2.53, wt=89),
    dict(name="W18x97", d=18.60, bf=11.145,tw=0.535, tf=0.870, A=28.5,  Ix=1750, Sx=188,  Zx=211,  ry=2.65, wt=97),
    dict(name="W21x101",d=21.40, bf=12.290,tw=0.500, tf=0.800, A=29.8,  Ix=2420, Sx=227,  Zx=253,  ry=2.89, wt=101),
    dict(name="W24x104",d=24.10, bf=12.750,tw=0.500, tf=0.750, A=30.6,  Ix=3100, Sx=258,  Zx=289,  ry=2.91, wt=104),
]

E = 29000.0     # ksi, steel modulus
IN_PER_MM = 1 / 25.4
KSI_PER_MPA = 0.145038


def mm_to_in(x_mm):
    return x_mm * IN_PER_MM


def diagonal_in(section):
    return math.hypot(section["d"], section["bf"])


def flexural_capacity(section, Fy, Lb_in, Cb=1.0):
    """phi*Mn per AISC 360-16 Ch. F2 (simplified Lr, see module docstring)."""
    ry = section["ry"]
    Sx = section["Sx"]
    Zx = section["Zx"]
    Mp = Fy * Zx                                   # kip-in
    Lp = 1.76 * ry * math.sqrt(E / Fy)              # in
    Lr = math.pi * ry * math.sqrt(E / (0.7 * Fy))   # in (simplified)

    if Lb_in <= Lp:
        Mn = Mp
        regime = "plastic (Lb<=Lp, or fully grout-braced)"
    elif Lb_in <= Lr:
        Mn = Cb * (Mp - (Mp - 0.7 * Fy * Sx) * (Lb_in - Lp) / (Lr - Lp))
        Mn = min(Mn, Mp)
        regime = "inelastic LTB"
    else:
        Mn = Cb * Mp * (Lr / Lb_in) ** 2
        Mn = min(Mn, Mp)
        regime = "elastic LTB (approx.)"

    phi_b = 0.90
    return phi_b * Mn, regime, Lp, Lr


def shear_capacity(section, Fy):
    """phi*Vn per AISC 360-16 Ch. G2.1, Cv1 = 1.0 (compact unstiffened web)."""
    Aw = section["d"] * section["tw"]
    phi_v = 0.90
    Vn = 0.6 * Fy * Aw * 1.0
    return phi_v * Vn


def axial_flexure_interaction(Pr, Pc, Mr, Mc):
    """AISC 360-16 Eq. H1-1a/H1-1b. Returns (ratio, governing_eq)."""
    if Pc <= 0:
        return (Mr / Mc if Mc else float("inf")), "H1-1b (no axial)"
    p = Pr / Pc
    if p >= 0.2:
        ratio = p + (8.0 / 9.0) * (Mr / Mc)
        return ratio, "H1-1a"
    else:
        ratio = p / 2.0 + (Mr / Mc)
        return ratio, "H1-1b"


def optimize(D_hole_mm, C_allowance_mm, Mu_kipin, Vu_kip,
             Fy_ksi=50.0, Lb_construction_mm=0.0, Pu_kip=0.0,
             allowance_is_per_side=True, top_n=5):
    """
    Grid search over AISC_W_SHAPES for the lightest section satisfying
    the geometric fit constraint and AISC 360 strength checks.

    Parameters
    ----------
    D_hole_mm            : drilled hole diameter (mm)
    C_allowance_mm        : construction allowance (mm) -- 50 / 75 / 100 typical
    Mu_kipin              : required flexural strength (kip-in), factored
    Vu_kip                : required shear strength (kip), factored
    Fy_ksi                : steel yield strength (ksi) -- 50 (Gr.50) default
    Lb_construction_mm    : unbraced length during install (0 = grout-braced)
    Pu_kip                : factored axial load (kip), optional (0 = ignore)
    allowance_is_per_side : True -> D_net = D - 2C ; False -> D_net = D - C
    top_n                 : number of ranked candidates to return
    """
    D_hole_in = mm_to_in(D_hole_mm)
    C_in = mm_to_in(C_allowance_mm)
    Lb_in = mm_to_in(Lb_construction_mm)
    D_net_in = D_hole_in - (2 * C_in if allowance_is_per_side else C_in)

    results = []
    for sec in AISC_W_SHAPES:
        diag = diagonal_in(sec)
        fits = diag <= D_net_in

        phiMn, regime, Lp, Lr = flexural_capacity(sec, Fy_ksi, Lb_in)
        phiVn = shear_capacity(sec, Fy_ksi)

        flex_ok = Mu_kipin <= phiMn
        shear_ok = Vu_kip <= phiVn

        if Pu_kip > 0:
            phiPn_approx = 0.9 * Fy_ksi * sec["A"]  # yielding-only proxy; use Ch.E for real Pn
            ratio, eq = axial_flexure_interaction(Pu_kip, phiPn_approx, Mu_kipin, phiMn)
            interaction_ok = ratio <= 1.0
        else:
            ratio, eq, interaction_ok = (Mu_kipin / phiMn if phiMn else float("inf")), "flexure only", flex_ok

        passes = fits and flex_ok and shear_ok and interaction_ok

        results.append(dict(
            name=sec["name"], weight_plf=sec["wt"], diagonal_in=round(diag, 3),
            D_net_in=round(D_net_in, 3), fits=fits,
            phiMn_kipin=round(phiMn, 1), regime=regime,
            phiVn_kip=round(phiVn, 1),
            util_flex=round(Mu_kipin / phiMn, 3) if phiMn else None,
            util_shear=round(Vu_kip / phiVn, 3) if phiVn else None,
            util_interaction=round(ratio, 3), interaction_eq=eq,
            passes_all=passes,
        ))

    admissible = [r for r in results if r["passes_all"]]
    admissible.sort(key=lambda r: r["weight_plf"])
    return dict(
        D_hole_in=D_hole_in, D_net_in=D_net_in,
        n_checked=len(results), n_admissible=len(admissible),
        ranked_candidates=admissible[:top_n],
        all_results=results,
    )


if __name__ == "__main__":
    # ---------------- INPUTS (edit for your project) ----------------
    INPUTS = dict(
        D_hole_mm=610,            # 24 in drilled hole
        C_allowance_mm=75,        # 50 / 75 / 100 mm tiers -- confirm w/ spec
        Mu_kipin=850.0,           # factored design moment
        Vu_kip=35.0,              # factored design shear
        Fy_ksi=50.0,              # ASTM A992 Grade 50
        Lb_construction_mm=0.0,   # 0 = grout-braced (in-service governs)
        Pu_kip=0.0,
        allowance_is_per_side=True,
        top_n=5,
    )
    out = optimize(**INPUTS)

    print(f"Hole diameter:            {INPUTS['D_hole_mm']} mm ({out['D_hole_in']:.2f} in)")
    print(f"Net available diagonal:   {out['D_net_in']:.2f} in "
          f"(allowance={INPUTS['C_allowance_mm']} mm, per-side={INPUTS['allowance_is_per_side']})")
    print(f"Sections checked: {out['n_checked']}  |  Geometrically+structurally admissible: {out['n_admissible']}")
    print("-" * 100)
    print(f"{'Section':<10}{'wt(plf)':>9}{'diag(in)':>10}{'fits':>7}"
          f"{'phiMn':>10}{'util_M':>9}{'phiVn':>9}{'util_V':>9}  regime")
    for r in out["ranked_candidates"]:
        print(f"{r['name']:<10}{r['weight_plf']:>9}{r['diagonal_in']:>10}{str(r['fits']):>7}"
              f"{r['phiMn_kipin']:>10}{r['util_flex']:>9}{r['phiVn_kip']:>9}{r['util_shear']:>9}  {r['regime']}")

    if out["ranked_candidates"]:
        best = out["ranked_candidates"][0]
        print(f"\nOPTIMUM (lightest admissible section): {best['name']}  "
              f"({best['weight_plf']} plf, M-util={best['util_flex']}, V-util={best['util_shear']})")
    else:
        print("\nNo admissible section found -- increase hole diameter, reduce allowance, "
              "or expand the section library.")
