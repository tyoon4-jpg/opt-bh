import React, { useState, useMemo } from "react";

/* ============================================================================
   CIP DRILLED-HOLE STEEL BEAM OPTIMIZER
   Design tokens: technical/blueprint register for a deep-foundation calc tool
   Palette:  bg #10151B, panel #171E27, line #2A3542, blueprint accent #3E92CC,
             steel #8B98A8, warn #F0B429, pass #4CAF7D, fail #E2574C, text #E7ECF2
   Type: "IBM Plex Sans" (labels/UI), "IBM Plex Mono" (all numeric data)
   Signature element: the live diagonal-fit roundel (hole / allowance ring /
   rotating beam silhouette) — the one governing geometric check, always visible.
   ========================================================================== */

const FONT_IMPORT_URL =
  "https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap";

/* ---------------------------------------------------------------------- */
/* SECTION LIBRARIES (mirrors optimized_beam_aisc.py / optimized_steel_beam.py) */
/* ---------------------------------------------------------------------- */
const AISC_W_SHAPES = [
  { name: "W8x31",  d: 8.00,  bf: 7.995, tw: 0.285, tf: 0.435, A: 9.13,  Sx: 27.5, Zx: 30.4, ry: 2.02, wt: 31 },
  { name: "W8x40",  d: 8.25,  bf: 8.070, tw: 0.360, tf: 0.560, A: 11.7, Sx: 35.5, Zx: 39.8, ry: 2.04, wt: 40 },
  { name: "W8x48",  d: 8.50,  bf: 8.110, tw: 0.400, tf: 0.685, A: 14.1, Sx: 43.2, Zx: 49.0, ry: 2.08, wt: 48 },
  { name: "W10x33", d: 9.73,  bf: 7.960, tw: 0.290, tf: 0.435, A: 9.71, Sx: 35.0, Zx: 38.8, ry: 1.94, wt: 33 },
  { name: "W10x45", d: 10.10, bf: 8.020, tw: 0.350, tf: 0.620, A: 13.3, Sx: 49.1, Zx: 54.9, ry: 2.01, wt: 45 },
  { name: "W10x60", d: 10.20, bf: 10.080, tw: 0.420, tf: 0.680, A: 17.6, Sx: 66.7, Zx: 74.6, ry: 2.57, wt: 60 },
  { name: "W12x40", d: 11.90, bf: 8.005, tw: 0.295, tf: 0.515, A: 11.7, Sx: 51.5, Zx: 57.0, ry: 1.94, wt: 40 },
  { name: "W12x53", d: 12.10, bf: 9.995, tw: 0.345, tf: 0.575, A: 15.6, Sx: 70.6, Zx: 77.9, ry: 2.48, wt: 53 },
  { name: "W12x65", d: 12.10, bf: 12.000, tw: 0.390, tf: 0.605, A: 19.1, Sx: 87.9, Zx: 96.8, ry: 3.02, wt: 65 },
  { name: "W14x53", d: 13.90, bf: 8.060, tw: 0.370, tf: 0.660, A: 15.6, Sx: 77.8, Zx: 87.1, ry: 1.92, wt: 53 },
  { name: "W14x68", d: 14.00, bf: 10.040, tw: 0.415, tf: 0.720, A: 20.0, Sx: 103, Zx: 115, ry: 2.46, wt: 68 },
  { name: "W14x90", d: 14.00, bf: 14.520, tw: 0.440, tf: 0.710, A: 26.5, Sx: 143, Zx: 157, ry: 3.70, wt: 90 },
  { name: "W16x89", d: 16.75, bf: 10.365, tw: 0.525, tf: 0.875, A: 26.2, Sx: 155, Zx: 175, ry: 2.53, wt: 89 },
  { name: "W18x97", d: 18.60, bf: 11.145, tw: 0.535, tf: 0.870, A: 28.5, Sx: 188, Zx: 211, ry: 2.65, wt: 97 },
  { name: "W21x101", d: 21.40, bf: 12.290, tw: 0.500, tf: 0.800, A: 29.8, Sx: 227, Zx: 253, ry: 2.89, wt: 101 },
  { name: "W24x104", d: 24.10, bf: 12.750, tw: 0.500, tf: 0.750, A: 30.6, Sx: 258, Zx: 289, ry: 2.91, wt: 104 },
];

const EN_SHAPES = [
  { name: "IPE300", h: 300, b: 150, tw: 7.1, tf: 10.7, A: 5380, Wply: 628.4, iz: 3.35, wt: 42.2 },
  { name: "IPE360", h: 360, b: 170, tw: 8.0, tf: 12.7, A: 7270, Wply: 1019, iz: 3.79, wt: 57.1 },
  { name: "IPE400", h: 400, b: 180, tw: 8.6, tf: 13.5, A: 8450, Wply: 1307, iz: 3.95, wt: 66.3 },
  { name: "IPE450", h: 450, b: 190, tw: 9.4, tf: 14.6, A: 9880, Wply: 1702, iz: 4.12, wt: 77.6 },
  { name: "IPE500", h: 500, b: 200, tw: 10.2, tf: 16.0, A: 11550, Wply: 2194, iz: 4.31, wt: 90.7 },
  { name: "HEB160", h: 160, b: 160, tw: 8.0, tf: 13.0, A: 5425, Wply: 354.0, iz: 3.98, wt: 42.6 },
  { name: "HEB180", h: 180, b: 180, tw: 8.5, tf: 14.0, A: 6525, Wply: 481.4, iz: 4.57, wt: 51.2 },
  { name: "HEB200", h: 200, b: 200, tw: 9.0, tf: 15.0, A: 7810, Wply: 642.5, iz: 5.07, wt: 61.3 },
  { name: "HEB220", h: 220, b: 220, tw: 9.5, tf: 16.0, A: 9100, Wply: 827.0, iz: 5.59, wt: 71.5 },
  { name: "HEB240", h: 240, b: 240, tw: 10.0, tf: 17.0, A: 10600, Wply: 1053, iz: 6.00, wt: 83.2 },
  { name: "HEB260", h: 260, b: 260, tw: 10.0, tf: 17.5, A: 11840, Wply: 1283, iz: 6.58, wt: 93.0 },
  { name: "HEB280", h: 280, b: 280, tw: 10.5, tf: 18.0, A: 13140, Wply: 1534, iz: 7.09, wt: 103.1 },
  { name: "HEB300", h: 300, b: 300, tw: 11.0, tf: 19.0, A: 14910, Wply: 1869, iz: 7.58, wt: 117.0 },
  { name: "HEM200", h: 220, b: 206, tw: 15.0, tf: 25.0, A: 13130, Wply: 1135, iz: 5.19, wt: 103.0 },
  { name: "HEM240", h: 270, b: 248, tw: 18.0, tf: 32.0, A: 22030, Wply: 2118, iz: 6.79, wt: 173.0 },
];

const E_KSI = 29000.0;
const E_MPA = 210000.0;
const MM_PER_IN = 25.4;

/* ---------------------------------------------------------------------- */
/* AISC 360-16 checks (mirrors optimized_beam_aisc.py) */
/* ---------------------------------------------------------------------- */
function aiscFlexure(sec, Fy, LbIn, Cb = 1.0) {
  const Mp = Fy * sec.Zx;
  const Lp = 1.76 * sec.ry * Math.sqrt(E_KSI / Fy);
  const Lr = Math.PI * sec.ry * Math.sqrt(E_KSI / (0.7 * Fy));
  let Mn, regime;
  if (LbIn <= Lp) {
    Mn = Mp;
    regime = "Plastic (grout-braced)";
  } else if (LbIn <= Lr) {
    Mn = Math.min(Cb * (Mp - (Mp - 0.7 * Fy * sec.Sx) * ((LbIn - Lp) / (Lr - Lp))), Mp);
    regime = "Inelastic LTB";
  } else {
    Mn = Math.min(Cb * Mp * Math.pow(Lr / LbIn, 2), Mp);
    regime = "Elastic LTB (approx.)";
  }
  return { phiMn: 0.9 * Mn, regime, Lp, Lr };
}
function aiscShear(sec, Fy) {
  const Aw = sec.d * sec.tw;
  return 0.9 * 0.6 * Fy * Aw;
}

/* ---------------------------------------------------------------------- */
/* EN 1993-1-1 checks (mirrors optimized_steel_beam.py) */
/* ---------------------------------------------------------------------- */
function enShear(sec, fy) {
  const Av = Math.max(sec.A - 2 * sec.b * sec.tf + sec.tw * sec.tf, sec.tw * (sec.h - 2 * sec.tf));
  return (Av * (fy / Math.sqrt(3))) / 1000; // kN
}
function enBending(sec, fy, VEd) {
  const McRd = (sec.Wply * 1e3 * fy) / 1e6; // kN-m
  const VplRd = enShear(sec, fy);
  if (VEd > 0.5 * VplRd) {
    const rho = Math.pow((2 * VEd) / VplRd - 1, 2);
    return McRd * (1 - rho * 0.25);
  }
  return McRd;
}
function enLTB(sec, fy, LbMm, McRd) {
  if (LbMm <= 0) return { MbRd: McRd, note: "Grout-braced (Lb=0)" };
  const IzMm4 = Math.pow(sec.iz * 10, 2) * sec.A;
  const Iw = (IzMm4 * Math.pow(sec.h - sec.tf, 2)) / 4;
  const Mcr = ((Math.PI ** 2 * E_MPA * IzMm4) / Math.pow(LbMm, 2)) * Math.sqrt(Iw / IzMm4) / 1e6;
  const WplyMm3 = sec.Wply * 1e3;
  const lamBar = Mcr > 0 ? Math.sqrt((WplyMm3 * fy) / (Mcr * 1e6)) : Infinity;
  const alphaLT = 0.34;
  const phiLT = 0.5 * (1 + alphaLT * (lamBar - 0.2) + lamBar ** 2);
  let chiLT = 1 / (phiLT + Math.sqrt(Math.max(phiLT ** 2 - lamBar ** 2, 1e-9)));
  chiLT = Math.min(chiLT, 1.0);
  const MbRd = (chiLT * WplyMm3 * fy) / 1e6;
  return { MbRd, note: `LTB governs, χLT=${chiLT.toFixed(3)}` };
}

/* ---------------------------------------------------------------------- */
/* Geometric fit (shared logic) */
/* ---------------------------------------------------------------------- */
function diagonalIn(sec) { return Math.hypot(sec.d, sec.bf); }
function diagonalMm(sec) { return Math.hypot(sec.h, sec.b); }

export default function CIPBeamOptimizer() {
  const [code, setCode] = useState("AISC");
  const [holeDia, setHoleDia] = useState(610); // mm, canonical unit for inputs
  const [allowance, setAllowance] = useState(75);
  const [customAllowance, setCustomAllowance] = useState("");
  const [perSide, setPerSide] = useState(true);
  const [grade, setGrade] = useState("default");
  const [demandM, setDemandM] = useState(code === "AISC" ? 850 : 95); // Mu(kip-in) or MEd(kN-m)
  const [demandV, setDemandV] = useState(code === "AISC" ? 35 : 155);
  const [braced, setBraced] = useState(true);
  const [LbMm, setLbMm] = useState(3000);

  const effAllowance = customAllowance !== "" ? parseFloat(customAllowance) : allowance;
  const D_net_mm = holeDia - (perSide ? 2 * effAllowance : effAllowance);
  const D_net_in = D_net_mm / MM_PER_IN;

  const Fy_ksi = grade === "A36" ? 36 : 50;
  const fy_mpa = grade === "S235" ? 235 : 355;

  const results = useMemo(() => {
    if (code === "AISC") {
      const LbIn = braced ? 0 : LbMm / MM_PER_IN;
      const MuKipin = demandM;
      const VuKip = demandV;
      const rows = AISC_W_SHAPES.map((sec) => {
        const diag = diagonalIn(sec);
        const fits = diag <= D_net_in;
        const { phiMn, regime } = aiscFlexure(sec, Fy_ksi, LbIn);
        const phiVn = aiscShear(sec, Fy_ksi);
        const utilM = phiMn ? MuKipin / phiMn : Infinity;
        const utilV = phiVn ? VuKip / phiVn : Infinity;
        const pass = fits && utilM <= 1 && utilV <= 1;
        return { name: sec.name, wt: sec.wt, diag, unit: "in", wtUnit: "plf", utilM, utilV, pass, regime, cap: phiMn };
      });
      return rows.sort((a, b) => a.wt - b.wt);
    } else {
      const LbMmVal = braced ? 0 : LbMm;
      const MEd = demandM;
      const VEd = demandV;
      const rows = EN_SHAPES.map((sec) => {
        const diag = diagonalMm(sec);
        const fits = diag <= D_net_mm;
        const McRd = enBending(sec, fy_mpa, VEd);
        const { MbRd, note } = enLTB(sec, fy_mpa, LbMmVal, McRd);
        const VplRd = enShear(sec, fy_mpa);
        const utilM = MbRd ? MEd / MbRd : Infinity;
        const utilV = VplRd ? VEd / VplRd : Infinity;
        const pass = fits && utilM <= 1 && utilV <= 1;
        return { name: sec.name, wt: sec.wt, diag, unit: "mm", wtUnit: "kg/m", utilM, utilV, pass, regime: note, cap: MbRd };
      });
      return rows.sort((a, b) => a.wt - b.wt);
    }
  }, [code, D_net_in, D_net_mm, demandM, demandV, Fy_ksi, fy_mpa, braced, LbMm]);

  const admissible = results.filter((r) => r.pass && r.diag <= (code === "AISC" ? D_net_in : D_net_mm));
  const optimum = admissible[0] || null;
  const showSec = optimum || results[0];

  // --- diagram geometry (SVG, always in a normalized 0-300 box) ---
  const boxDiaMm = holeDia;
  const scale = 130 / (boxDiaMm / 2 || 1);
  const holeR = (boxDiaMm / 2) * scale;
  const netR = (D_net_mm / 2) * scale;
  const secDiagMm = showSec ? (code === "AISC" ? showSec.diag * MM_PER_IN : showSec.diag) : 0;
  const secDimsMm =
    showSec && code === "AISC"
      ? { h: AISC_W_SHAPES.find((s) => s.name === showSec.name)?.d * MM_PER_IN, b: AISC_W_SHAPES.find((s) => s.name === showSec.name)?.bf * MM_PER_IN }
      : showSec
      ? { h: EN_SHAPES.find((s) => s.name === showSec.name)?.h, b: EN_SHAPES.find((s) => s.name === showSec.name)?.b }
      : { h: 0, b: 0 };
  const bh = (secDimsMm.h || 0) * scale;
  const bw = (secDimsMm.b || 0) * scale;

  return (
    <div style={styles.app}>
      <style>{`
        @import url('${FONT_IMPORT_URL}');
        * { box-sizing: border-box; }
        input[type=number]::-webkit-inner-spin-button { opacity: 1; }
        .toggleBtn { cursor:pointer; user-select:none; }
        .toggleBtn:hover { filter: brightness(1.15); }
        .rowHover:hover { background: #1D2733 !important; }
      `}</style>

      <header style={styles.header}>
        <div>
          <div style={styles.eyebrow}>DEEP FOUNDATIONS · CIP DRILLED-HOLE STEEL BEAM</div>
          <h1 style={styles.h1}>Beam-in-Hole Fit &amp; Capacity Optimizer</h1>
        </div>
        <div style={styles.codeToggle}>
          {["AISC", "EN"].map((c) => (
            <div
              key={c}
              className="toggleBtn"
              onClick={() => {
                setCode(c);
                setDemandM(c === "AISC" ? 850 : 95);
                setDemandV(c === "AISC" ? 35 : 155);
              }}
              style={{
                ...styles.codeToggleBtn,
                background: code === c ? "#3E92CC" : "transparent",
                color: code === c ? "#0D1117" : "#8B98A8",
              }}
            >
              {c === "AISC" ? "AISC 360" : "EN 1993-1-1"}
            </div>
          ))}
        </div>
      </header>

      <div style={styles.grid}>
        {/* -------- LEFT: INPUTS -------- */}
        <section style={styles.panel}>
          <div style={styles.panelTitle}>01 · Hole geometry</div>

          <Field label="Drilling hole diameter (mm)">
            <input type="number" value={holeDia} min={200} step={10}
              onChange={(e) => setHoleDia(parseFloat(e.target.value) || 0)} style={styles.input} />
          </Field>

          <Field label="Construction allowance">
            <div style={styles.chipRow}>
              {[50, 75, 100].map((v) => (
                <div key={v} className="toggleBtn"
                  onClick={() => { setAllowance(v); setCustomAllowance(""); }}
                  style={{ ...styles.chip, ...(allowance === v && customAllowance === "" ? styles.chipActive : {}) }}>
                  {v} mm
                </div>
              ))}
              <input type="number" placeholder="custom" value={customAllowance}
                onChange={(e) => setCustomAllowance(e.target.value)}
                style={{ ...styles.input, width: 84, padding: "6px 8px" }} />
            </div>
            <div style={styles.helpText}>
              Practice-based defaults, not code-mandated — confirm against project spec.
              See note below.
            </div>
          </Field>

          <Field label="Allowance basis">
            <div style={styles.chipRow}>
              <div className="toggleBtn" onClick={() => setPerSide(true)}
                style={{ ...styles.chip, ...(perSide ? styles.chipActive : {}) }}>Per side (× 2)</div>
              <div className="toggleBtn" onClick={() => setPerSide(false)}
                style={{ ...styles.chip, ...(!perSide ? styles.chipActive : {}) }}>Total clearance</div>
            </div>
          </Field>

          <div style={styles.divider} />
          <div style={styles.panelTitle}>02 · Design actions &amp; material</div>

          <Field label={code === "AISC" ? "Mu — factored moment (kip·in)" : "MEd — design moment (kN·m)"}>
            <input type="number" value={demandM} onChange={(e) => setDemandM(parseFloat(e.target.value) || 0)} style={styles.input} />
          </Field>
          <Field label={code === "AISC" ? "Vu — factored shear (kip)" : "VEd — design shear (kN)"}>
            <input type="number" value={demandV} onChange={(e) => setDemandV(parseFloat(e.target.value) || 0)} style={styles.input} />
          </Field>
          <Field label="Steel grade">
            <div style={styles.chipRow}>
              {(code === "AISC" ? ["default", "A36"] : ["default", "S235"]).map((g) => (
                <div key={g} className="toggleBtn" onClick={() => setGrade(g)}
                  style={{ ...styles.chip, ...(grade === g ? styles.chipActive : {}) }}>
                  {g === "default" ? (code === "AISC" ? "Gr.50 (Fy=50ksi)" : "S355 (fy=355MPa)") : g}
                </div>
              ))}
            </div>
          </Field>

          <div style={styles.divider} />
          <div style={styles.panelTitle}>03 · Lateral bracing condition</div>
          <div style={styles.chipRow}>
            <div className="toggleBtn" onClick={() => setBraced(true)}
              style={{ ...styles.chip, ...(braced ? styles.chipActive : {}) }}>Grout-braced (Lb=0)</div>
            <div className="toggleBtn" onClick={() => setBraced(false)}
              style={{ ...styles.chip, ...(!braced ? styles.chipActive : {}) }}>Construction stage</div>
          </div>
          {!braced && (
            <Field label="Unbraced length Lb (mm)">
              <input type="number" value={LbMm} onChange={(e) => setLbMm(parseFloat(e.target.value) || 0)} style={styles.input} />
            </Field>
          )}
        </section>

        {/* -------- CENTER: DIAGRAM -------- */}
        <section style={styles.panel}>
          <div style={styles.panelTitle}>Governing geometric check</div>
          <svg viewBox="0 0 300 300" style={styles.svg}>
            <circle cx="150" cy="150" r={holeR} fill="none" stroke="#2A3542" strokeWidth="2" />
            <circle cx="150" cy="150" r={netR > 0 ? netR : 0} fill="none" stroke="#3E92CC" strokeWidth="1.5" strokeDasharray="4 3" />
            {showSec && bh > 0 && bw > 0 && (
              <g transform={`translate(150,150) rotate(38)`}>
                {/* simplified H-beam silhouette: web + two flanges */}
                <rect x={-bw / 2} y={-bh / 2} width={bw} height={bh * 0.14} fill="#F0B429" opacity="0.9" />
                <rect x={-bw / 2} y={bh / 2 - bh * 0.14} width={bw} height={bh * 0.14} fill="#F0B429" opacity="0.9" />
                <rect x={-bh * 0.06} y={-bh / 2} width={bh * 0.12} height={bh} fill="#F0B429" opacity="0.9" />
                <line x1={-bw / 2} y1={-bh / 2} x2={bw / 2} y2={bh / 2} stroke="#0D1117" strokeWidth="1" strokeDasharray="2 2" />
              </g>
            )}
            <text x="150" y="18" textAnchor="middle" fill="#8B98A8" fontSize="9" fontFamily="IBM Plex Mono">
              HOLE ⌀ {holeDia} mm
            </text>
            <text x="150" y="288" textAnchor="middle" fill="#3E92CC" fontSize="9" fontFamily="IBM Plex Mono">
              NET DIAGONAL ⌀ {D_net_mm.toFixed(0)} mm
            </text>
          </svg>
          <div style={styles.diagramLegend}>
            <LegendDot color="#2A3542" label="Drilled hole" />
            <LegendDot color="#3E92CC" label="Net available diagonal" dashed />
            <LegendDot color="#F0B429" label={showSec ? `Section shown: ${showSec.name}` : "No section"} />
          </div>
          <div style={{ ...styles.calloutBox, marginTop: 14 }}>
            <div style={styles.calloutLabel}>Net diagonal available</div>
            <div style={styles.calloutValue}>
              {D_net_mm.toFixed(0)} <span style={styles.calloutUnit}>mm</span>
              <span style={styles.calloutSub}> / {D_net_in.toFixed(2)} in</span>
            </div>
            <div style={styles.helpText}>
              D_net = D_hole − {perSide ? "2 ×" : ""} allowance = {holeDia} − {perSide ? `2×${effAllowance}` : effAllowance} mm
            </div>
          </div>
        </section>

        {/* -------- RIGHT: RESULTS -------- */}
        <section style={styles.panel}>
          <div style={styles.panelTitle}>Ranked candidates (lightest admissible first)</div>
          <div style={styles.tableWrap}>
            <table style={styles.table}>
              <thead>
                <tr>
                  <th style={styles.th}>Section</th>
                  <th style={styles.th}>Wt.</th>
                  <th style={styles.th}>Diag.</th>
                  <th style={styles.th}>Fit</th>
                  <th style={styles.th}>M util.</th>
                  <th style={styles.th}>V util.</th>
                </tr>
              </thead>
              <tbody>
                {results.map((r) => {
                  const fits = r.diag <= (code === "AISC" ? D_net_in : D_net_mm);
                  return (
                    <tr key={r.name} className="rowHover"
                      style={{ background: optimum && r.name === optimum.name ? "#16301F" : "transparent" }}>
                      <td style={styles.td}>{r.name}</td>
                      <td style={{ ...styles.td, ...styles.mono }}>{r.wt} {r.wtUnit}</td>
                      <td style={{ ...styles.td, ...styles.mono }}>{r.diag.toFixed(1)} {r.unit}</td>
                      <td style={styles.td}><Badge ok={fits} /></td>
                      <td style={{ ...styles.td, ...styles.mono, color: r.utilM <= 1 ? "#4CAF7D" : "#E2574C" }}>
                        {isFinite(r.utilM) ? r.utilM.toFixed(2) : "—"}
                      </td>
                      <td style={{ ...styles.td, ...styles.mono, color: r.utilV <= 1 ? "#4CAF7D" : "#E2574C" }}>
                        {isFinite(r.utilV) ? r.utilV.toFixed(2) : "—"}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {optimum ? (
            <div style={{ ...styles.calloutBox, borderColor: "#4CAF7D", marginTop: 14 }}>
              <div style={{ ...styles.calloutLabel, color: "#4CAF7D" }}>Optimum section</div>
              <div style={styles.calloutValue}>{optimum.name}</div>
              <div style={styles.helpText}>
                {optimum.wt} {optimum.wtUnit} · {optimum.regime} · M util. {optimum.utilM.toFixed(2)}, V util. {optimum.utilV.toFixed(2)}
              </div>
            </div>
          ) : (
            <div style={{ ...styles.calloutBox, borderColor: "#E2574C", marginTop: 14 }}>
              <div style={{ ...styles.calloutLabel, color: "#E2574C" }}>No admissible section</div>
              <div style={styles.helpText}>Increase hole diameter, reduce allowance, or relax demand — no library section fits and passes.</div>
            </div>
          )}
        </section>
      </div>

      <footer style={styles.footer}>
        Screening-grade tool (Phase 1) — simplified LTB, no biaxial/seismic detailing. Section properties are indicative;
        verify against current AISC Manual / EN 10365 tables before final, stamped design. Construction allowance tiers
        are practice-based defaults — confirm against project specification.
      </footer>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={styles.label}>{label}</div>
      {children}
    </div>
  );
}
function Badge({ ok }) {
  return (
    <span style={{
      display: "inline-block", padding: "1px 7px", borderRadius: 3, fontSize: 10.5,
      fontFamily: "IBM Plex Mono", letterSpacing: 0.3,
      background: ok ? "rgba(76,175,125,0.15)" : "rgba(226,87,76,0.15)",
      color: ok ? "#4CAF7D" : "#E2574C", border: `1px solid ${ok ? "#4CAF7D" : "#E2574C"}`,
    }}>
      {ok ? "FITS" : "NO FIT"}
    </span>
  );
}
function LegendDot({ color, label, dashed }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 10.5, color: "#8B98A8", fontFamily: "IBM Plex Sans" }}>
      <span style={{ width: 10, height: 10, borderRadius: dashed ? 0 : 2, background: dashed ? "transparent" : color, border: `1.5px ${dashed ? "dashed" : "solid"} ${color}` }} />
      {label}
    </div>
  );
}

const styles = {
  app: {
    background: "#10151B", minHeight: "100%", padding: "28px 28px 20px",
    fontFamily: "'IBM Plex Sans', sans-serif", color: "#E7ECF2",
  },
  header: { display: "flex", justifyContent: "space-between", alignItems: "flex-end", flexWrap: "wrap", gap: 14, marginBottom: 22 },
  eyebrow: { fontFamily: "'IBM Plex Mono', monospace", fontSize: 11, letterSpacing: 1.5, color: "#3E92CC", marginBottom: 6 },
  h1: { fontSize: 22, fontWeight: 600, margin: 0, letterSpacing: -0.2 },
  codeToggle: { display: "flex", border: "1px solid #2A3542", borderRadius: 6, overflow: "hidden" },
  codeToggleBtn: { padding: "8px 16px", fontSize: 12.5, fontWeight: 600, fontFamily: "'IBM Plex Mono', monospace", transition: "all .15s" },
  grid: { display: "grid", gridTemplateColumns: "1.1fr 1fr 1.3fr", gap: 16 },
  panel: { background: "#171E27", border: "1px solid #232C38", borderRadius: 8, padding: 18 },
  panelTitle: { fontSize: 11, fontWeight: 600, letterSpacing: 1, color: "#8B98A8", textTransform: "uppercase", marginBottom: 14 },
  label: { fontSize: 12, color: "#B3BCC7", marginBottom: 6 },
  input: {
    width: "100%", background: "#0D1319", border: "1px solid #2A3542", borderRadius: 5,
    color: "#E7ECF2", padding: "8px 10px", fontFamily: "'IBM Plex Mono', monospace", fontSize: 13, outline: "none",
  },
  chipRow: { display: "flex", gap: 6, flexWrap: "wrap" },
  chip: {
    padding: "6px 11px", borderRadius: 5, border: "1px solid #2A3542", fontSize: 12,
    color: "#8B98A8", fontFamily: "'IBM Plex Mono', monospace",
  },
  chipActive: { background: "#3E92CC", color: "#0D1117", borderColor: "#3E92CC", fontWeight: 600 },
  helpText: { fontSize: 10.5, color: "#5C6774", marginTop: 6, lineHeight: 1.5 },
  divider: { height: 1, background: "#232C38", margin: "18px 0" },
  svg: { width: "100%", height: "auto", display: "block" },
  diagramLegend: { display: "flex", flexDirection: "column", gap: 6, marginTop: 10 },
  calloutBox: { border: "1px solid #2A3542", borderRadius: 6, padding: "12px 14px", background: "#0D1319" },
  calloutLabel: { fontSize: 10.5, letterSpacing: 0.8, textTransform: "uppercase", color: "#8B98A8", marginBottom: 4 },
  calloutValue: { fontSize: 22, fontWeight: 600, fontFamily: "'IBM Plex Mono', monospace" },
  calloutUnit: { fontSize: 13, color: "#8B98A8", fontWeight: 400 },
  calloutSub: { fontSize: 12, color: "#5C6774", marginLeft: 6 },
  tableWrap: { maxHeight: 360, overflowY: "auto", border: "1px solid #232C38", borderRadius: 6 },
  table: { width: "100%", borderCollapse: "collapse", fontSize: 12 },
  th: {
    position: "sticky", top: 0, background: "#1B2330", textAlign: "left", padding: "8px 10px",
    fontSize: 10, letterSpacing: 0.6, color: "#8B98A8", textTransform: "uppercase", borderBottom: "1px solid #2A3542",
  },
  td: { padding: "7px 10px", borderBottom: "1px solid #1D2530" },
  mono: { fontFamily: "'IBM Plex Mono', monospace" },
  footer: { marginTop: 18, fontSize: 10.5, color: "#5C6774", lineHeight: 1.6, maxWidth: 980 },
};
