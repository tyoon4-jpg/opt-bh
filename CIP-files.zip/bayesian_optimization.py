"""
bayesian_optimization.py
==========================
Phase 2 (PLANNED / prototype) - Bayesian refinement layer for the CIP beam
optimizer.

WHY BAYESIAN OPTIMIZATION, GIVEN THE GRID SEARCH ALREADY WORKS
------------------------------------------------------------------
optimized_beam_aisc.py / optimized_steel_beam.py exhaustively check every
standard section in a small discrete library (15-20 entries) -- a grid
search is the *correct* tool there; nothing is gained by replacing it.

BO earns its place once the design space stops being a short discrete
catalog, e.g.:
  - screening BUILT-UP / custom-fabricated H-sections (continuous d, bf,
    tw, tf, rather than a fixed catalog), where exhaustive grid search
    over 4 continuous variables gets expensive;
  - jointly optimizing the beam AND the construction allowance /
    hole diameter within a feasible project range, to find the
    hole-diameter sweet spot that minimizes total installed cost
    (drilling cost scales with D_hole^2; steel cost scales with weight);
  - cases where the "capacity check" is itself expensive (e.g. calling
    out to LPILE/PLAXIS for a soil-structure interaction based capacity
    instead of a closed-form AISC/EC3 formula) and each evaluation should
    be minimized.

This module demonstrates the pattern with a lightweight, dependency-free
Gaussian Process (numpy only -- no scikit-learn/skopt required) so it can
run in the same environment as the two grid-search scripts. It optimizes
the CONTINUOUS proxy design space (d, bf) for a custom H-section subject
to the same geometric-fit constraint, using a weight-vs-capacity surrogate,
then reports the nearest standard catalog section for cross-checking.

STATUS: prototype / Phase 2 roadmap item, not yet wired into the PRD's
Phase 1 acceptance criteria. Treat results as illustrative.
"""

import math
import numpy as np

E_KSI = 29000.0


# ----------------------------------------------------------------------
# Simplified continuous section-property model for a custom doubly-
# symmetric wide-flange proxy, parameterized only by (d, bf), holding
# tw, tf as functions of d, bf via typical rolled-shape proportions.
# This is a coarse surrogate for BO demonstration -- swap in a real
# section-property generator (or an FE-based property calc) for
# production use.
# ----------------------------------------------------------------------
def proxy_section_properties(d_in, bf_in):
    tw = max(0.24 * (d_in / 12.0), 0.22)     # in, rough proportion
    tf = max(0.35 * (bf_in / 8.0), 0.30)     # in, rough proportion
    A = 2 * bf_in * tf + (d_in - 2 * tf) * tw
    Ix = (bf_in * d_in ** 3) / 12.0 - ((bf_in - tw) * (d_in - 2 * tf) ** 3) / 12.0
    Sx = Ix / (d_in / 2.0)
    Zx = 1.12 * Sx  # typical shape factor approx. for wide-flange shapes
    wt_plf = A * 3.4  # in^2 -> plf, ~3.4 plf per in^2 for steel
    diagonal = math.hypot(d_in, bf_in)
    return dict(A=A, Ix=Ix, Sx=Sx, Zx=Zx, wt=wt_plf, diagonal=diagonal)


def objective(d_in, bf_in, D_net_in, Mu_kipin, Fy_ksi=50.0, penalty=1e4):
    """
    Minimize steel weight subject to: fits within D_net_in and Mp >= Mu.
    Infeasible points are heavily penalized (kept smooth-ish for the GP).
    """
    props = proxy_section_properties(d_in, bf_in)
    Mp = Fy_ksi * props["Zx"]

    fit_violation = max(0.0, props["diagonal"] - D_net_in)
    strength_violation = max(0.0, Mu_kipin - Mp) / max(Mu_kipin, 1.0)

    cost = props["wt"] + penalty * (fit_violation + strength_violation)
    return cost, props


# ----------------------------------------------------------------------
# Minimal Gaussian Process (RBF kernel) + Upper-Confidence-Bound BO loop.
# Deliberately dependency-free (numpy only) for portability.
# ----------------------------------------------------------------------
class SimpleGP:
    def __init__(self, length_scale=2.0, sigma_f=1.0, sigma_n=1e-3):
        self.length_scale = length_scale
        self.sigma_f = sigma_f
        self.sigma_n = sigma_n
        self.X = None
        self.y = None

    def _kernel(self, X1, X2):
        d2 = np.sum((X1[:, None, :] - X2[None, :, :]) ** 2, axis=-1)
        return self.sigma_f ** 2 * np.exp(-0.5 * d2 / self.length_scale ** 2)

    def fit(self, X, y):
        self.X = X
        self.y = y
        K = self._kernel(X, X) + self.sigma_n ** 2 * np.eye(len(X))
        self.L = np.linalg.cholesky(K)
        self.alpha = np.linalg.solve(self.L.T, np.linalg.solve(self.L, y))

    def predict(self, Xs):
        Ks = self._kernel(self.X, Xs)
        mu = Ks.T @ self.alpha
        v = np.linalg.solve(self.L, Ks)
        var = self.sigma_f ** 2 - np.sum(v ** 2, axis=0)
        var = np.maximum(var, 1e-9)
        return mu, np.sqrt(var)


def bayesian_refine(D_net_in, Mu_kipin, Fy_ksi=50.0, n_init=6, n_iter=15,
                     d_bounds=(8.0, 24.0), bf_bounds=(6.0, 16.0), seed=42,
                     kappa=1.5):
    """
    UCB-driven BO search over (d, bf) minimizing the penalized weight
    objective. Returns the best (d, bf, cost, props) found plus history.
    """
    rng = np.random.default_rng(seed)

    X = rng.uniform([d_bounds[0], bf_bounds[0]], [d_bounds[1], bf_bounds[1]], size=(n_init, 2))
    y = np.array([objective(x[0], x[1], D_net_in, Mu_kipin, Fy_ksi)[0] for x in X])

    gp = SimpleGP(length_scale=3.0, sigma_f=max(y.std(), 1.0))

    history = list(zip(X.tolist(), y.tolist()))

    for _ in range(n_iter):
        gp.fit(X, y)
        # candidate pool for acquisition maximization (LCB, since minimizing)
        cand = rng.uniform([d_bounds[0], bf_bounds[0]], [d_bounds[1], bf_bounds[1]], size=(500, 2))
        mu, sigma = gp.predict(cand)
        lcb = mu - kappa * sigma  # explore-exploit; lower is better since we minimize
        next_x = cand[np.argmin(lcb)]
        next_y, _ = objective(next_x[0], next_x[1], D_net_in, Mu_kipin, Fy_ksi)

        X = np.vstack([X, next_x])
        y = np.append(y, next_y)
        history.append((next_x.tolist(), float(next_y)))

    best_idx = int(np.argmin(y))
    best_d, best_bf = X[best_idx]
    best_cost = y[best_idx]
    _, best_props = objective(best_d, best_bf, D_net_in, Mu_kipin, Fy_ksi)

    return dict(
        d_in=round(float(best_d), 2), bf_in=round(float(best_bf), 2),
        cost=round(float(best_cost), 3), properties=best_props,
        n_evaluations=len(y), history=history,
    )


def nearest_catalog_match(d_in, bf_in, catalog):
    """Report closest standard section by Euclidean (d, bf) distance, for
    cross-checking a BO result against a real, fabricable/available shape."""
    best, best_dist = None, float("inf")
    for sec in catalog:
        dist = math.hypot(sec["d"] - d_in, sec["bf"] - bf_in)
        if dist < best_dist:
            best, best_dist = sec, dist
    return best, best_dist


if __name__ == "__main__":
    # Example: same demo case as optimized_beam_aisc.py
    D_hole_in = 24.02
    C_in = 75 / 25.4
    D_net_in = D_hole_in - 2 * C_in
    Mu_kipin = 850.0

    print("Bayesian refinement over continuous (d, bf) proxy space")
    print(f"D_net_in = {D_net_in:.2f} in, Mu = {Mu_kipin} kip-in\n")

    result = bayesian_refine(D_net_in, Mu_kipin, n_init=6, n_iter=20)
    print(f"Best proxy design: d={result['d_in']} in, bf={result['bf_in']} in "
          f"({result['n_evaluations']} evaluations)")
    print(f"  weight ~= {result['properties']['wt']:.1f} plf, "
          f"diagonal = {result['properties']['diagonal']:.2f} in "
          f"(limit {D_net_in:.2f} in), Zx ~= {result['properties']['Zx']:.1f} in^3")

    try:
        from optimized_beam_aisc import AISC_W_SHAPES
        match, dist = nearest_catalog_match(result["d_in"], result["bf_in"], AISC_W_SHAPES)
        print(f"\nNearest standard AISC catalog match: {match['name']} "
              f"(d={match['d']}in, bf={match['bf']}in, wt={match['wt']}plf) "
              f"-- distance={dist:.2f} in")
        print("Use this as the practical selection; the BO result is a sizing "
              "target for custom/built-up sections only.")
    except ImportError:
        pass
