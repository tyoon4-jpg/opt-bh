"""
optimized_steel_beam.py
========================
CIP (cast-in-place) drilled-hole steel beam optimizer — Eurocode 3 method
(EN 1993-1-1). Renamed from the originally-specified "optimized_steel_beam.m"
to a .py extension since the routine is written in Python, not MATLAB/Octave
— flag this if an .m (MATLAB) version is actually required and it can be
transliterated; the algorithm is language-agnostic.

PURPOSE
-------
Grid search over a library of standard European HE-B and IPE sections to
find the lightest section that satisfies:

  1. GEOMETRIC FIT   diagonal = sqrt(h^2 + b^2) <= D_hole - 2*C_allowance
  2. STRENGTH         EN 1993-1-1 bending (6.2.5), shear (6.2.6), and,
                       optionally, N-M interaction (6.2.9) / LTB (6.3.2).

See optimized_beam_aisc.py for the shared geometric-fit derivation and the
notes on the 50/75/100 mm construction allowance tiers (same logic applies
here — those values are practice-based defaults, not EN-code-mandated).

STRENGTH MODEL (Phase 1 - screening grade; see PRD Section 5 for full scope)
--------------------------------------------------------------------------
Bending resistance, Class 1/2 sections (EN 1993-1-1 6.2.5):
    Mc,Rd = Wpl,y * fy / gammaM0        (gammaM0 = 1.00)

Shear resistance (6.2.6), unstiffened web:
    Av      ~= A - 2*b*tf + (tw)*tf     (simplified approximation of 6.2.6(3))
    Vpl,Rd  = Av * (fy / sqrt(3)) / gammaM0

Bending-shear interaction (6.2.8): if VEd > 0.5*Vpl,Rd, reduce fy in the
shear area by (1 - rho) with rho = (2VEd/Vpl,Rd - 1)^2 before computing
Mc,Rd. Implemented below.

Lateral-torsional buckling (6.3.2, simplified screening form):
    Once the beam is fully grout/concrete-encased (post-cure), it is
    continuously laterally restrained -> Mb,Rd = Mc,Rd (Lb ~ 0).
    For the temporary/construction condition (Lb > 0), this script uses a
    simplified elastic critical moment approximation:
        Iw  ~= Iz * (h - tf)^2 / 4          (thin-walled I-section approx.)
        Mcr ~= (pi^2 * E * Iz / Lb^2) * sqrt(Iw / Iz)
        lambda_LT_bar = sqrt(Wpl,y * fy / Mcr)
        phi_LT = 0.5*[1 + alphaLT*(lambda_LT_bar - 0.2) + lambda_LT_bar^2],  alphaLT = 0.34 (curve b, rolled)
        chi_LT = 1 / (phi_LT + sqrt(phi_LT^2 - lambda_LT_bar^2))  , capped at 1.0
        Mb,Rd = chi_LT * Wpl,y * fy / gammaM1   (gammaM1 = 1.00)
    This omits the torsion constant It term in Mcr and is therefore
    CONSERVATIVE but approximate. For final design use LTBeam, software
    with full Mcr (It, Iw, C1), or EN 1993-1-1 Annex-based hand calc.

N-M interaction (6.2.9.1), optional if NEd supplied:
    Simplified linear check for Class 1/2 I-sections about major axis:
        MN,y,Rd = Mc,Rd * (1 - n) / (1 - 0.5*aw) ,  n = NEd/Npl,Rd ,
        aw = min((A - 2*b*tf)/A, 0.5)

USAGE
-----
    python optimized_steel_beam.py

Edit the INPUTS block, or import `optimize()`.
"""

import math

# ----------------------------------------------------------------------
# 1. SECTION LIBRARY (SI units: mm, mm^2, mm^3 (10^3 for Wpl), kg/m)
#    Indicative EN 10365 values for HE-B and IPE series.
#    VERIFY against current EN 10365 / producer tables before final design.
# ----------------------------------------------------------------------
EN_SHAPES = [
    # name,      h,    b,    tw,   tf,   A(mm2), Iy(cm4), Wply(cm3), iz(cm), wt(kg/m)
    dict(name="IPE300",  h=300, b=150, tw=7.1,  tf=10.7, A=5380,  Iy=8356,  Wply=628.4,  iz=3.35, wt=42.2),
    dict(name="IPE360",  h=360, b=170, tw=8.0,  tf=12.7, A=7270,  Iy=16270, Wply=1019,   iz=3.79, wt=57.1),
    dict(name="IPE400",  h=400, b=180, tw=8.6,  tf=13.5, A=8450,  Iy=23130, Wply=1307,   iz=3.95, wt=66.3),
    dict(name="IPE450",  h=450, b=190, tw=9.4,  tf=14.6, A=9880,  Iy=33740, Wply=1702,   iz=4.12, wt=77.6),
    dict(name="IPE500",  h=500, b=200, tw=10.2, tf=16.0, A=11550, Iy=48200, Wply=2194,   iz=4.31, wt=90.7),
    dict(name="HEB160",  h=160, b=160, tw=8.0,  tf=13.0, A=5425,  Iy=2492,  Wply=354.0,  iz=3.98, wt=42.6),
    dict(name="HEB180",  h=180, b=180, tw=8.5,  tf=14.0, A=6525,  Iy=3831,  Wply=481.4,  iz=4.57, wt=51.2),
    dict(name="HEB200",  h=200, b=200, tw=9.0,  tf=15.0, A=7810,  Iy=5696,  Wply=642.5,  iz=5.07, wt=61.3),
    dict(name="HEB220",  h=220, b=220, tw=9.5,  tf=16.0, A=9100,  Iy=8091,  Wply=827.0,  iz=5.59, wt=71.5),
    dict(name="HEB240",  h=240, b=240, tw=10.0, tf=17.0, A=10600, Iy=11259, Wply=1053,   iz=6.00, wt=83.2),
    dict(name="HEB260",  h=260, b=260, tw=10.0, tf=17.5, A=11840, Iy=14920, Wply=1283,   iz=6.58, wt=93.0),
    dict(name="HEB280",  h=280, b=280, tw=10.5, tf=18.0, A=13140, Iy=19270, Wply=1534,   iz=7.09, wt=103.1),
    dict(name="HEB300",  h=300, b=300, tw=11.0, tf=19.0, A=14910, Iy=25170, Wply=1869,   iz=7.58, wt=117.0),
    dict(name="HEM200",  h=220, b=206, tw=15.0, tf=25.0, A=13130, Iy=10640, Wply=1135,   iz=5.19, wt=103.0),
    dict(name="HEM240",  h=270, b=248, tw=18.0, tf=32.0, A=22030, Iy=24290, Wply=2118,   iz=6.79, wt=173.0),
]

E = 210000.0   # MPa
G = 81000.0    # MPa (unused in simplified Mcr, kept for future refinement)
GAMMA_M0 = 1.00
GAMMA_M1 = 1.00


def diagonal_mm(section):
    return math.hypot(section["h"], section["b"])


def bending_resistance(section, fy, VEd=0.0):
    """Mc,Rd in kN-m, applying 6.2.8 shear interaction if VEd > 0.5*Vpl,Rd."""
    Wply_mm3 = section["Wply"] * 1e3
    Mc_Rd = Wply_mm3 * fy / GAMMA_M0 / 1e6  # kN-m

    Vpl_Rd = shear_resistance(section, fy)
    if VEd > 0.5 * Vpl_Rd:
        rho = (2 * VEd / Vpl_Rd - 1) ** 2
        # reduce web contribution to Wpl (approx.: reduce whole Wpl by rho*Aw*(h-tf)^2/(4*Wpl) term
        # simplified screening reduction:
        Mc_Rd = Mc_Rd * (1 - rho * 0.25)
    return Mc_Rd


def shear_resistance(section, fy):
    """Vpl,Rd in kN, simplified shear-area approximation."""
    A_mm2 = section["A"]
    b, tf, tw = section["b"], section["tf"], section["tw"]
    Av = max(A_mm2 - 2 * b * tf + tw * tf, tw * (section["h"] - 2 * tf))  # mm^2, simplified
    Vpl_Rd = Av * (fy / math.sqrt(3)) / GAMMA_M0 / 1e3  # kN
    return Vpl_Rd


def ltb_resistance(section, fy, Lb_mm, Mc_Rd_kNm):
    """Mb,Rd in kN-m. Lb=0 -> fully grout-braced -> Mb,Rd = Mc,Rd."""
    if Lb_mm <= 0:
        return Mc_Rd_kNm, "grout-braced (Lb=0)"

    Iz_mm4 = section["iz"] ** 2 * 1e2 * section["A"]  # iz(cm) -> iz(mm), Iz=iz^2*A
    Iz_mm4 = (section["iz"] * 10) ** 2 * section["A"]
    Iw = Iz_mm4 * (section["h"] - section["tf"]) ** 2 / 4.0  # mm^6
    Mcr = (math.pi ** 2 * E * Iz_mm4 / Lb_mm ** 2) * math.sqrt(Iw / Iz_mm4) / 1e6  # kN-m (approx, no It term)

    Wply_mm3 = section["Wply"] * 1e3
    lam_bar = math.sqrt(Wply_mm3 * fy / (Mcr * 1e6)) if Mcr > 0 else float("inf")
    alphaLT = 0.34  # curve b, rolled I-sections
    phi_LT = 0.5 * (1 + alphaLT * (lam_bar - 0.2) + lam_bar ** 2)
    chi_LT = 1.0 / (phi_LT + math.sqrt(max(phi_LT ** 2 - lam_bar ** 2, 1e-9)))
    chi_LT = min(chi_LT, 1.0)

    Mb_Rd = chi_LT * Wply_mm3 * fy / GAMMA_M1 / 1e6
    return Mb_Rd, f"LTB governs, chi_LT={chi_LT:.3f}, lambda_LT_bar={lam_bar:.3f}"


def nm_interaction(NEd_kN, section, fy, Mc_Rd_kNm):
    """Simplified EN 1993-1-1 6.2.9.1 linear N-M check for I-sections."""
    Npl_Rd = section["A"] * fy / GAMMA_M0 / 1e3  # kN
    n = NEd_kN / Npl_Rd if Npl_Rd else 0.0
    aw = min((section["A"] - 2 * section["b"] * section["tf"]) / section["A"], 0.5)
    if n <= aw:
        MN_Rd = Mc_Rd_kNm
    else:
        MN_Rd = Mc_Rd_kNm * (1 - n) / (1 - 0.5 * aw)
    return MN_Rd, n


def optimize(D_hole_mm, C_allowance_mm, MEd_kNm, VEd_kN,
             fy_MPa=355.0, Lb_construction_mm=0.0, NEd_kN=0.0,
             allowance_is_per_side=True, top_n=5):
    """
    Grid search over EN_SHAPES for the lightest admissible section.

    Parameters mirror optimized_beam_aisc.optimize(), in EN/SI units:
    D_hole_mm, C_allowance_mm : hole geometry (mm)
    MEd_kNm, VEd_kN           : design action effects (factored)
    fy_MPa                     : 355 (S355) default, 235 (S235) alt.
    Lb_construction_mm         : 0 = grout-braced; >0 = construction stage
    NEd_kN                     : optional factored axial force
    """
    D_net_mm = D_hole_mm - (2 * C_allowance_mm if allowance_is_per_side else C_allowance_mm)

    results = []
    for sec in EN_SHAPES:
        diag = diagonal_mm(sec)
        fits = diag <= D_net_mm

        Mc_Rd = bending_resistance(sec, fy_MPa, VEd_kN)
        Vpl_Rd = shear_resistance(sec, fy_MPa)
        Mb_Rd, ltb_note = ltb_resistance(sec, fy_MPa, Lb_construction_mm, Mc_Rd)

        if NEd_kN > 0:
            MN_Rd, n = nm_interaction(NEd_kN, sec, fy_MPa, Mb_Rd)
            gov_Rd = MN_Rd
            note = f"N-M interaction, n={n:.3f}"
        else:
            gov_Rd = Mb_Rd
            note = ltb_note

        flex_ok = MEd_kNm <= gov_Rd
        shear_ok = VEd_kN <= Vpl_Rd
        passes = fits and flex_ok and shear_ok

        results.append(dict(
            name=sec["name"], weight_kgpm=sec["wt"], diagonal_mm=round(diag, 1),
            D_net_mm=round(D_net_mm, 1), fits=fits,
            MRd_kNm=round(gov_Rd, 1), note=note,
            VplRd_kN=round(Vpl_Rd, 1),
            util_flex=round(MEd_kNm / gov_Rd, 3) if gov_Rd else None,
            util_shear=round(VEd_kN / Vpl_Rd, 3) if Vpl_Rd else None,
            passes_all=passes,
        ))

    admissible = [r for r in results if r["passes_all"]]
    admissible.sort(key=lambda r: r["weight_kgpm"])
    return dict(
        D_net_mm=D_net_mm, n_checked=len(results), n_admissible=len(admissible),
        ranked_candidates=admissible[:top_n], all_results=results,
    )


if __name__ == "__main__":
    INPUTS = dict(
        D_hole_mm=610,          # 610 mm drilled hole
        C_allowance_mm=75,      # 50 / 75 / 100 mm tiers -- confirm w/ spec
        MEd_kNm=95.0,           # factored design moment
        VEd_kN=155.0,           # factored design shear
        fy_MPa=355.0,           # S355
        Lb_construction_mm=0.0, # grout-braced in-service condition
        NEd_kN=0.0,
        allowance_is_per_side=True,
        top_n=5,
    )
    out = optimize(**INPUTS)

    print(f"Hole diameter: {INPUTS['D_hole_mm']} mm | Net diagonal available: {out['D_net_mm']:.1f} mm "
          f"(allowance={INPUTS['C_allowance_mm']} mm, per-side={INPUTS['allowance_is_per_side']})")
    print(f"Sections checked: {out['n_checked']}  |  Admissible: {out['n_admissible']}")
    print("-" * 100)
    print(f"{'Section':<10}{'wt(kg/m)':>10}{'diag(mm)':>10}{'fits':>7}"
          f"{'MRd(kNm)':>10}{'util_M':>9}{'VplRd(kN)':>11}{'util_V':>9}  note")
    for r in out["ranked_candidates"]:
        print(f"{r['name']:<10}{r['weight_kgpm']:>10}{r['diagonal_mm']:>10}{str(r['fits']):>7}"
              f"{r['MRd_kNm']:>10}{r['util_flex']:>9}{r['VplRd_kN']:>11}{r['util_shear']:>9}  {r['note']}")

    if out["ranked_candidates"]:
        best = out["ranked_candidates"][0]
        print(f"\nOPTIMUM (lightest admissible section): {best['name']}  "
              f"({best['weight_kgpm']} kg/m, M-util={best['util_flex']}, V-util={best['util_shear']})")
    else:
        print("\nNo admissible section found -- increase hole diameter, reduce allowance, "
              "or expand the section library.")
